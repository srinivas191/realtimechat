
const socket = io('http://localhost:8000');

// Get DOM elements in respective Js Variables
const form = document.getElementById('send-container')
const messageInput = document.getElementById('messageInp')
const messageContainer = document.querySelector(".container")

// Audio will play in on receiving messages
var audio = new Audio('drop.mp3');

// Function which will append event info to the container
const append = (message, position) => {
    const messageElement = document.createElement('div');
    messageElement.innerText = message;
    messageElement.classList.add('message');
    messageElement.classList.add(position);
    messageContainer.append(messageElement);
     if(position == 'left'){
        audio.play();
     }
     messageContainer.scrollTop = messageContainer.scrollHeight;
 }

// If form is submitted, send message to the server 
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const message=messageInput.value;
    append(`You : ${message}`,'right');
    
    socket.emit('send',message);
    messageInput.value = '';
});

// Ask the new user for his/her name and let the server know
const nam = prompt("Enter your name to join");
socket.emit('new-user-joined', nam);

// If new user joined append his/her name from the server
socket.on('user-joined', name => {
    append(`${name} joined the chat`, 'right')
})

// If server send message,append it
socket.on('receive', data=>{
    append(`${data.name} : ${data.message}`,'left')
})

// If any user dissconnect, append info from server
socket.on('left',name=>{
    append(`${name} left the chat`,'left');
})
