//Node server which will handle the socket io connections
const io = require('socket.io')(8000, {cors: {origin: "*"}});

const users = {};

io.on('connection', socket => {
    // If new user joins, let other users connected to server know!
    socket.on('new-user-joined', name => {
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });

    // If someone send message, broadcast it to other people
    socket.on('send', async message=>{
        socket.broadcast.emit('receive',{message : message, name : users[socket.id]});
    });

    // If someone dissconncted, let other users connected to server know! 
    socket.on('disconnect', () =>{
        socket.broadcast.emit('left', users[socket.id]);
        delete users[socket.id];
    });

});
